using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;



public class CollisionBullet : MonoBehaviour
{
    private float reactionTimer = 0;
    public KeyCode StartKey = KeyCode.Space;
    static string dataPath = Directory.GetCurrentDirectory() + "/Assets/Data/";
    string logFile = dataPath + "Data" + ".csv";
    public static string log; // new line of data
    public float StartTime = 0;

    public static bool detectCollision = true; // FIX

    void Start()
    {
        if (!Directory.Exists(dataPath))
        {
            Directory.CreateDirectory(dataPath);
        }
        if (!File.Exists(logFile))
        {
            File.WriteAllText(logFile, "Time, Distance, ypos, zpos, Angle\n");
        }
        
        

    }

    public void OnTriggerEnter(Collider col)
    {
        log = "";
        if (col.gameObject.name == "Target")
        {
           
            Vector3 offsetPosition = new Vector3(gameObject.transform.position.x - 15, gameObject.transform.position.y - 4, gameObject.transform.position.z);
            double ypos = gameObject.transform.position.y - 4;
            double zpos = gameObject.transform.position.z;
            Debug.Log(offsetPosition);
            double distance = Math.Sqrt(ypos * ypos + zpos * zpos);
            double angle = Math.Atan(Math.Abs(zpos) / 15.0);
            log += distance + "dis, " + ypos + "ypos, " + zpos + "zpos, " + angle + "angle";
            File.AppendAllText(logFile, log + Environment.NewLine);
            log = "";
            detectCollision = true;
        }
    }

}